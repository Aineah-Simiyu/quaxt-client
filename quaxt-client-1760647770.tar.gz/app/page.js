import LoginPage from "./(auth)/login/page"
export default function Landing() {
  return (
    <LoginPage />
  )
}